<?php 
    require_once("Conexion.php");

    class Pasajero extends Conexion {
        private $pcedula;
        private $pnombres;
        private $correo;
        private $celular;

        public function __construct(){

            $this->conexion = new Conexion();
            $this->conexion = $this->conexion->getConect();
        }

        public function insertPasajero($cedula, $nombres, $correo, $celular){

            $this->pcedula = $cedula;
            $this->pnombres = $nombres;
            $this->pcorreo = $correo;
            $this->pceluar = $celular;

            //utilizar una sentencia SQL para insertar datos
            $sql = "INSERT INTO pasajero(pcedula, pnombres, pcorreo, pcelular) VALUES(?,?,?,?)";
            //utilizar el medo de PDo para preparar la consulta SQL
            $insert = $this->conexion->prepare($sql);
            //paso los datos a través de un arreglo
            $arrData = array($this->pcedula, $this->pnombres, $this->pcorreo, $this->pcelular);
            $resulInsert = $insert->execute($arrData);
            $idInsert = $this->conexion->lastInsertId();
            return $idInsert;


        }

    }

?>