<?php 

    require_once("rutas.php");

    $objRutas = new Rutas();

    $insert = $objRutas->insertRuta("70", "Candelaria -Popayan", 62000.50);
    echo $insert;
?>