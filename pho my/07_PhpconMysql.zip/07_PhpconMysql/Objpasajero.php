<?php 

    require_once("Pasajero.php");

    $objPasajero = new Pasajero();

    //Insertar un pasajero
    $insertarReg = $objPasajero->insertPasajero("30","Juan Camilo Díaz","juan@sistemas.com","3012342212");
    echo $insertarReg;
?>